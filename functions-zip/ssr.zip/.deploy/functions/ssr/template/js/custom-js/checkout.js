// Add your custom JavaScript for checkout here.
window.ecomPaymentApps = [1251, 1250]
